# Copyright (c) 2024 Arturo Gutierrez Rubio Rojas
# Licensed under the MIT License

import hashlib
import pandas as pd

# --- Hashing ---

def hash_sha256(value) -> str:
    """
    Aplica hashing SHA-256 a cualquier valor (convierte a str).
    Retorna hex digest completo.
    """
    if value is None:
        return ""
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()

def hash_truncated(value, length: int = 12) -> str:
    """
    Hash SHA-256 truncado (por ejemplo, para llaves de join anónimas).
    """
    return hash_sha256(value)[:max(1, int(length))]


# --- Enmascaramientos ---

def mask_string(value: str, num_prefix: int = 2, num_suffix: int = 0, mask_char: str = "*") -> str:
    """
    Enmascara cadena dejando visibles `num_prefix` y `num_suffix` caracteres.
    """
    if value is None:
        return ""
    s = str(value)
    if len(s) <= (num_prefix + num_suffix):
        return mask_char * len(s)
    return s[:num_prefix] + (mask_char * (len(s) - num_prefix - num_suffix)) + s[-num_suffix:] if num_suffix > 0 else s[:num_prefix] + (mask_char * (len(s) - num_prefix))

def mask_email(email: str) -> str:
    """
    Enmascara emails dejando 2 primeros caracteres del usuario visibles.
    """
    if not email:
        return ""
    email = str(email)
    if "@" not in email:
        return mask_string(email, num_prefix=2)
    user, domain = email.split("@", 1)
    user_mask = mask_string(user, num_prefix=2)
    return f"{user_mask}@{domain}"

def mask_zip_code(zip_code) -> str:
    """
    Enmascara código postal dejando solo 2 primeros dígitos visibles.
    """
    if zip_code is None:
        return ""
    s = str(zip_code)
    return s[:2] + "*" * max(0, len(s) - 2)

def mask_date(date_str) -> str:
    """
    Enmascara completamente la fecha (YYYY-**-**).
    Acepta varios formatos, devuelve forma segura.
    """
    if date_str is None:
        return ""
    s = str(date_str)
    # Mantén año si parece plausible, oculta mes y día
    if len(s) >= 4 and s[:4].isdigit():
        return s[:4] + "-**-**"
    return "****-**-**"


# --- Heurística por nombre de columna ---

def is_pii_column(col_name: str) -> bool:
    """
    Detección básica por nombre de columna.
    """
    if not col_name:
        return False
    pii_keywords = ["name", "email", "address", "ssn", "card", "cvv", "zip", "postal", "dob", "birth"]
    lower = col_name.lower()
    return any(k in lower for k in pii_keywords)
