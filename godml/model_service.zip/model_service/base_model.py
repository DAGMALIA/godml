# godml/model_service/base_model.py
from abc import ABC, abstractmethod
import pandas as pd
from typing import Any


class BaseRegressionModel(ABC):
    """
    Clase base abstracta para modelos de regresión supervisados en GODML.
    Todos los modelos deben heredar e implementar estos métodos.
    """

    def __init__(self, **kwargs):
        self.model = None
        self.params = kwargs

    @abstractmethod
    def train(self, X: pd.DataFrame, y: pd.Series) -> Any:
        """Entrena el modelo con los datos proporcionados."""
        pass

    @abstractmethod
    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Genera predicciones con el modelo entrenado."""
        pass

    @abstractmethod
    def evaluate(self, X: pd.DataFrame, y: pd.Series) -> dict:
        """Evalúa el modelo y devuelve un diccionario de métricas."""
        pass
